/// Hello World as a program (posh Winnie-the-Pooh version)
//# Purpose: Demo Hello World as a program
fn main() {
    let other = "World 🌍";
    println!("Hello, {other}!");
}
