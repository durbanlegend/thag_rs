//: Demo a simple iterator
//# Purpose: Show how basic a snippet can be.
for i in 1..=5 {
    println!("{i}");
}
