//: Minimalist Hello World snippet (poor Winnie-the-Pooh version)
//# Purpose: Demo Hello World reduced to an expression
"Hello, World! 🌍"
