/*[toml]
[dependencies]
clap = { version = "4.5.7", features = ["cargo", "derive"] }
clap-repl = "0.1.1"
console = "0.15.8"
rustyline = { version = "14.0.0", features=["with-file-history", "default"] }
shlex = "1.3.0"
strum = { version = "0.26.2", features = ["derive"] }
*/

/// Experiment with matching REPL commands with a partial match of any length.
//# Purpose: Usability: Accept a command as long as the user has typed in enough characters to identify it uniquely.
use clap::{CommandFactory, Parser};
use console::style;
use rustyline::DefaultEditor;
use std::error::Error;
use std::str::FromStr;
use strum::{EnumIter, EnumString, IntoEnumIterator, IntoStaticStr};

#[derive(Debug, Parser, EnumIter, EnumString, IntoStaticStr)]
#[command(name = "", disable_help_flag = true, disable_help_subcommand = true)] // Disable automatic help subcommand and flag
#[strum(serialize_all = "kebab-case")]
enum LoopCommand {
    /// Evaluate an expression. Enclose complex expressions in braces {}.
    Eval,
    /// Enter, paste or modify your code
    Edit,
    /// Enter, paste or modify the generated Cargo.toml file your code
    Toml,
    /// List generated files
    List,
    /// Delete generated files
    Delete,
    /// Exit REPL
    Quit,
    /// Show help information
    Help,
}

impl LoopCommand {
    fn print_help() {
        let mut command = LoopCommand::command();
        let mut buf = Vec::new();
        command.write_help(&mut buf).unwrap();
        let help_message = String::from_utf8(buf).unwrap();
        println!("{}", help_message);
    }
}

fn main() -> Result<(), Box<dyn Error>> {
    let mut rl = DefaultEditor::new().unwrap();

    let cmd_vec = LoopCommand::iter()
        .map(<LoopCommand as Into<&'static str>>::into)
        .map(String::from)
        .collect::<Vec<String>>();
    let cmd_list =
        "Enter full or partial match of one of the following: ".to_owned() + &cmd_vec.join(", ");

    println!("{cmd_list}");
    loop {
        let line = match rl.readline(">> ") {
            Ok(x) => x,
            Err(e) => match e {
                rustyline::error::ReadlineError::Eof
                | rustyline::error::ReadlineError::Interrupted => break,
                rustyline::error::ReadlineError::WindowResized => continue,
                _ => panic!("Error in read line: {e:?}"),
            },
        };
        if line.trim().is_empty() {
            continue;
        }
        _ = rl.add_history_entry(line.as_str());
        let command = match shlex::split(&line) {
            Some(split) => {
                // eprintln!("split={split:?}");
                let mut matches = 0;
                let first_word = split[0].as_str();
                let mut cmd = String::new();
                for key in cmd_vec.iter() {
                    if key.starts_with(first_word) {
                        matches += 1;
                        // Selects last match
                        if matches == 1 {
                            cmd = key.to_string();
                        }
                        // eprintln!("key={key}, split[0]={}", split[0]);
                    }
                }
                if matches == 1 {
                    cmd
                } else {
                    println!("No single matching key found");
                    continue;
                }
            }
            None => {
                println!(
                    "{} input was not valid and could not be processed",
                    style("error:").red().bold()
                );
                LoopCommand::print_help();
                continue;
            }
        };
        println!(
            "command={command}, matching variant={:#?}",
            LoopCommand::from_str(&command)?
        );
        if command == "help" {
            println!();
            LoopCommand::print_help();
            continue;
        }
    }
    Ok(())
}
