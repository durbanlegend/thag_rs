//: Obligatory Hello World as a snippet
//# Purpose: Demo Hello World snippet
let other = "World";
println!("Hello, {other}!");
